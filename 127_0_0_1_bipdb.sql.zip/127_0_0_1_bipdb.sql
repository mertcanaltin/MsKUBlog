-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 18 Ara 2018, 20:29:44
-- Sunucu sürümü: 5.7.21
-- PHP Sürümü: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `bipdb`
--
DROP DATABASE IF EXISTS `bipdb`;
CREATE DATABASE IF NOT EXISTS `bipdb` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci;
USE `bipdb`;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `menu_tablosu`
--

DROP TABLE IF EXISTS `menu_tablosu`;
CREATE TABLE IF NOT EXISTS `menu_tablosu` (
  `menu_no` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `menu_baslik` varchar(120) COLLATE utf8mb4_turkish_ci NOT NULL,
  `menu_link` varchar(250) COLLATE utf8mb4_turkish_ci NOT NULL,
  `menu_hedef` varchar(10) COLLATE utf8mb4_turkish_ci NOT NULL DEFAULT '_self',
  `dil` varchar(3) COLLATE utf8mb4_turkish_ci NOT NULL DEFAULT 'TR',
  `ust_menu_id` bigint(20) UNSIGNED NOT NULL,
  PRIMARY KEY (`menu_no`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `menu_tablosu`
--

INSERT INTO `menu_tablosu` (`menu_no`, `menu_baslik`, `menu_link`, `menu_hedef`, `dil`, `ust_menu_id`) VALUES
(1, 'Misyon Vizyon', 'sayfa.php?sno=1', '_self', 'TR', 0),
(2, 'Tarihçe', 'sayfa.php?sno=2', '_self', 'TR', 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `sayfa_tablosu`
--

DROP TABLE IF EXISTS `sayfa_tablosu`;
CREATE TABLE IF NOT EXISTS `sayfa_tablosu` (
  `sayfa_no` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `sayfa_baslik` varchar(200) COLLATE utf8mb4_turkish_ci NOT NULL,
  `link_baslik` varchar(200) COLLATE utf8mb4_turkish_ci NOT NULL,
  `sayfa_icerik` text COLLATE utf8mb4_turkish_ci NOT NULL,
  `anahtar_kelimeler` varchar(250) COLLATE utf8mb4_turkish_ci NOT NULL,
  `dil` varchar(3) COLLATE utf8mb4_turkish_ci NOT NULL DEFAULT 'TR',
  `olusturma_tarihi` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `guncelleme_tarihi` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sayfa_no`),
  UNIQUE KEY `sayfa_no` (`sayfa_no`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `sayfa_tablosu`
--

INSERT INTO `sayfa_tablosu` (`sayfa_no`, `sayfa_baslik`, `link_baslik`, `sayfa_icerik`, `anahtar_kelimeler`, `dil`, `olusturma_tarihi`, `guncelleme_tarihi`) VALUES
(1, 'Muğla Sıtkı Koçman Üniversitesi Misyonu ve Vizyonu', 'misyon_vizyon', '<p>\r\n	Evrensel bilgi birikimine katkı sağlayan, yenilik&ccedil;i araştırmalar yapan ve topluma hizmet &uuml;reten bilim insanlarının rehberliğinde ger&ccedil;ekleştirdiği eğitim-&ouml;ğretimle ulusal ve uluslararası alanlarda aranan se&ccedil;kin mezunlar yetiştirmektir.</p>\r\n<p>\r\n	<img alt=\"\" src=\"http://www.mu.edu.tr/Icerik/Sayfa/bidb.mu.edu.tr/misyon-1.png\" /></p>\r\n<p>\r\n	<span style=\"color:#000080;\"><strong>Muğla Sıtkı Ko&ccedil;man &Uuml;niversitesinin vizyonu;</strong></span></p>\r\n<p>\r\n	Uluslararası standartlarda ger&ccedil;ekleştirdiği eğitim-&ouml;ğretim, araştırma ve uygulamalarıyla insanlığa hizmetler sunan, bu hizmetlerin toplumsal refaha d&ouml;n&uuml;şt&uuml;r&uuml;lmesine &ouml;nc&uuml;l&uuml;k eden bir d&uuml;nya &uuml;niversitesi olmaktır.</p>\r\n', 'Muğla, Sıtkı, Koçman, Misyon, Vizyon', 'TR', '2018-12-04 21:05:05', '2018-12-04 00:00:00'),
(2, 'Tarihçe', 'tarihce', '<div>\r\n	<p style=\"margin: 11.25pt 0cm; text-align: justify; line-height: normal; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">\r\n		Muğla Sıtkı Ko&ccedil;man &Uuml;niversitesi, 1992 tarihinde kurulmuştur. &Uuml;niversitemizin kuruluşunda Fen-Edebiyat, Su &Uuml;r&uuml;nleri, Teknik Eğitim, İktisad&icirc; ve İdar&icirc; Bilimler Fak&uuml;lteleri, Fen ve Sosyal Bilimler Enstit&uuml;leri, Turizm İşletmeciliği ve Otelcilik Y&uuml;ksekokulu yer almıştır. Muğla&rsquo;daki ilk y&uuml;ksek&ouml;ğrenim birimleri ise 1975 yılında Ankara İktisad&icirc; ve Ticar&icirc; İlimler Akademisine bağlı olarak kurulmuş, 1982 yılında ise Dokuz Eyl&uuml;l &Uuml;niversitesine bağlanmış olan Muğla İşletmecilik Y&uuml;ksekokulu ile 1989 yılında Dokuz Eyl&uuml;l &Uuml;niversitesine bağlı olarak kurulmuş olan Muğla Meslek Y&uuml;ksekokuludur. &Uuml;niversitemizin kurulmasıyla Muğla İşletmecilik Y&uuml;ksekokulu İktisad&icirc; ve İdar&icirc; Bilimler Fak&uuml;ltesine, Muğla Meslek Y&uuml;ksekokulu da &Uuml;niversitemize bağlanmıştır.&nbsp;1993 yılı iki aktif fak&uuml;lte ve iki meslek y&uuml;ksekokulu ile okulumuzun ilk &ouml;ğrencilerini aldığı akademik yıl olmuştur.&nbsp;&nbsp;</p>\r\n	<p style=\"margin: 11.25pt 0cm; text-align: justify; line-height: normal; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">\r\n		&nbsp;</p>\r\n	<p style=\"margin: 11.25pt 0cm; text-align: justify; line-height: normal; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">\r\n		&nbsp;</p>\r\n	<p style=\"margin: 11.25pt 0cm; text-align: justify; line-height: normal; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">\r\n		&nbsp;</p>\r\n</div>\r\n<p style=\"margin: 15px 0px; padding: 0px; border: 0px; outline: 0px;      text-align: justify;\">\r\n	<a href=\"http://www.mu.edu.tr/Icerik/Sayfa/bidb.mu.edu.tr/tarihce2.png\" rel=\"link\" style=\"margin: 0px; padding: 0px; border: 0px; outline: 0px; text-decoration: none; color: rgb(0, 0, 0); cursor: pointer;\" title=\"Tarihçe-2\"><img alt=\"\" src=\"http://www.mu.edu.tr/Icerik/Sayfa/bidb.mu.edu.tr/tarihce2.png\" style=\"margin: 0px 0px 0px 10px; padding: 5px; border: 1px solid rgb(175, 174, 176); outline: 0px; max-width: 580px; width: 300px; height: 200px; float: right;\" /></a></p>\r\n<p style=\"margin: 15px 0px; padding: 0px; border: 0px; outline: 0px;       text-align: justify;\">\r\n	Fen-Edebiyat Fak&uuml;ltesi ve Sağlık Hizmetleri Meslek Y&uuml;ksekokulu 1992 yılında, Fen Bilimleri Enstit&uuml;s&uuml; ve Sosyal Bilimler Enstit&uuml;s&uuml; 1994 yılında, Ula Ali Ko&ccedil;man Meslek Y&uuml;ksekokulu ve Ortaca Meslek Y&uuml;ksekokulu 1994 yılında, Milas Sıtkı Ko&ccedil;man Meslek Y&uuml;ksekokulu ile Spor Bilimleri Fak&uuml;ltesi (Beden Eğitimi ve Spor Y&uuml;ksekokulu) 1995 yılında, Sağlık Bilimleri Fak&uuml;ltesi (Muğla Sağlık Y&uuml;ksekokulu), Sağlık Hizmetleri Meslek Y&uuml;ksekokulu (Marmaris Sağlık Y&uuml;ksekokulu) ve Teknik Eğitim Fak&uuml;ltesi 1997 yılında, Fethiye Ali Sıtkı Mefharet Ko&ccedil;man Meslek Y&uuml;ksekokulu 1998 yılında, Dalaman Meslek Y&uuml;ksekokulu 1999 yılında, Eğitim Fak&uuml;ltesi ile Turizm Fak&uuml;ltesi (Turizm ve Otel İşletmeciliği Y&uuml;ksekokulu) 2001 yılında, Fethiye Sağlık Bilimleri Fak&uuml;ltesi (Fethiye Sağlık Okulu) 2002 yılında, G&uuml;zel Sanatlar Fak&uuml;ltesi, Su &Uuml;r&uuml;nleri Fak&uuml;ltesi ve Yatağan Meslek Y&uuml;ksekokulu ise 2004 yılında, M&uuml;hendislik Fak&uuml;ltesi ile Dat&ccedil;a Kazım Yılmaz Meslek Y&uuml;ksekokulu 2006 yılında, Eğitim Bilimleri Enstit&uuml;s&uuml; 2010 yılında, Tıp Fak&uuml;ltesi, Edebiyat Fak&uuml;ltesi, Fen Fak&uuml;ltesi, Teknoloji Fak&uuml;ltesi ve K&ouml;yceğiz Meslek Y&uuml;ksekokulu 2011 yılında, Sağlık Bilimleri Enstit&uuml;s&uuml;, Bodrum Denizcilik Meslek Y&uuml;ksekokulu ve İ&ccedil;meler Turizm Meslek Y&uuml;ksekokulu 2012 yılında ilk &ouml;ğrencilerini almıştır. Yabancı Diller Y&uuml;ksekokulu (Sıtkı Ko&ccedil;man Yabancı Diller Y&uuml;ksekokulu) 2005 yılında eğitim-&ouml;ğretim faaliyetlerine başlamıştır. Fethiye İşletme Fak&uuml;ltesi 2014 yılında, Dalaman Sivil Havacılık Y&uuml;ksekokulu 2017 yılında, Mimarlık Fak&uuml;ltesi, Milas Veteriner Fak&uuml;ltesi, Kavaklıdere Şehit Mustafa Alper Meslek Y&uuml;ksekokulu ve Seydikemer Uygulamalı Bilimler Y&uuml;ksekokulu 2018 yılında ilk &ouml;ğrencilerini almıştır.</p>\r\n<div style=\"margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 13px;     text-align: justify;\">\r\n	<p style=\"margin: 15px 0px; padding: 0px; border: 0px; outline: 0px;\">\r\n		Diş Hekimliği Fak&uuml;ltesi, İslami İlimler Fak&uuml;ltesi ve Fethiye Ziraat Fak&uuml;ltesi kurulmuş ancak eğitim-&ouml;ğretim faaliyetlerine hen&uuml;z başlanmamıştır.</p>\r\n	<p style=\"margin: 15px 0px; padding: 0px; border: 0px; outline: 0px;\">\r\n		Kurulduğu g&uuml;nden bu yana, Muğla Sıtkı Ko&ccedil;man &Uuml;niversitesi &uuml;lkemizin sosyo-k&uuml;lt&uuml;rel, bilimsel ve teknolojik gelişmesine katkıda bulunma, y&uuml;ksek kalitede y&uuml;ksek&ouml;ğrenim ve araştırma sunma amacında olmuştur. Sistematik ve kapsamlı bir eğitim programı geliştirilmesi yeterli bir altyapı gerektirir fikri ile hareket eden Muğla Sıtkı Ko&ccedil;man &Uuml;niversitesi 1994 yılında hızlı bir gelişme ve yatırım projesi başlatmıştır. &Uuml;niversitemizin bu &ccedil;abalarına okulumuzun hamisi Sıtkı Ko&ccedil;man c&ouml;mert mali katkılarıyla destek olmuştur. Sıtkı Ko&ccedil;man&rsquo;ın desteklerinden dolayı, 2012 yılına kadar Muğla &Uuml;niversitesi olan kurumumuzun ismi 31 Mayıs 2012 tarih ve 28309 sayılı Resmi Gazete&rsquo;de yayımlanan kararla Muğla Sıtkı Ko&ccedil;man &Uuml;niversitesi olarak değişti.</p>\r\n	<p style=\"margin: 15px 0px; padding: 0px; border: 0px; outline: 0px;\">\r\n		Sosyal Bilimler, Fen Bilimleri, Eğitim Bilimleri, Sanat ve Beşeri Bilimler ile mesleki eğitim alanlarında g&uuml;venilir bir eğitim sunma amacıyla kurulduğunda, Muğla Sıtkı Ko&ccedil;man &Uuml;niversitesinin sadece bir b&ouml;l&uuml;m&uuml;, 1.128 &ouml;ğrencisi ve &uuml;&ccedil; programı vardı. Muğla Sıtkı Ko&ccedil;man &Uuml;niversitesi bug&uuml;n 20 fak&uuml;lte, 4 enstit&uuml;, 3 y&uuml;ksekokul, 16 meslek y&uuml;ksekokulu, 47 araştırma ve uygulama merkezi ile 208.000 metrekare kapalı alan &uuml;zerinde 44.607 &ouml;ğrencisi, 1608 &ouml;ğretim elemanı ve 827 idari personeliyle hizmet veren gen&ccedil; ama hızla gelişen bir &uuml;niversite olmaktan gurur duymaktadır.</p>\r\n	<p style=\"margin: 15px 0px; padding: 0px; border: 0px; outline: 0px;\">\r\n		<a href=\"http://www.mu.edu.tr/Icerik/Sayfa/bidb.mu.edu.tr/tarihce3.png\" rel=\"link\" style=\"margin: 0px; padding: 0px; border: 0px; outline: 0px; text-decoration: none; color: rgb(0, 0, 0); cursor: pointer; text-align: center;\" title=\"Tarihçe-3\"><img alt=\"\" src=\"http://www.mu.edu.tr/Icerik/Sayfa/bidb.mu.edu.tr/tarihce3.png\" style=\"margin: 0px 10px 0px 0px; padding: 5px; border: 1px solid rgb(175, 174, 176); outline: 0px; max-width: 580px; text-align: justify; width: 160px; height: 103px; float: left;\" /></a></p>\r\n	<p style=\"margin: 15px 0px; padding: 0px; border: 0px; outline: 0px;\">\r\n		<a href=\"http://www.mu.edu.tr/Icerik/Sayfa/bidb.mu.edu.tr/tarihce4.png\" rel=\"link\" style=\"margin: 0px; padding: 0px; border: 0px; outline: 0px; text-decoration: none; color: rgb(0, 0, 0); cursor: pointer; text-align: center;\" title=\"Tarihçe-4\"><img alt=\"\" src=\"http://www.mu.edu.tr/Icerik/Sayfa/bidb.mu.edu.tr/tarihce4.png\" style=\"margin: 0px 10px 0px 0px; padding: 5px; border: 1px solid rgb(175, 174, 176); outline: 0px; max-width: 580px; text-align: justify; width: 160px; height: 108px; float: left;\" /></a></p>\r\n	<p style=\"margin: 15px 0px; padding: 0px; border: 0px; outline: 0px; text-align: center;\">\r\n		<a href=\"http://www.mu.edu.tr/Icerik/Sayfa/bidb.mu.edu.tr/tarihce5.png\" rel=\"link\" style=\"margin: 0px; padding: 0px; border: 0px; outline: 0px; text-decoration: none; color: rgb(0, 0, 0); cursor: pointer;\" title=\"Tarihçe-5\"><img alt=\"\" src=\"http://www.mu.edu.tr/Icerik/Sayfa/bidb.mu.edu.tr/tarihce5.png\" style=\"margin: 0px 10px 0px 0px; padding: 5px; border: 1px solid rgb(175, 174, 176); outline: 0px; max-width: 580px; text-align: justify; width: 160px; height: 108px; float: left;\" /></a></p>\r\n</div>', 'tarihçe, muğla, sıtkı, koçman, üniversite', 'TR', '2018-12-04 21:07:32', '2018-12-04 00:00:00'),
(3, 'Sonunda', 'Oldu', 'Bitti', 'Basit Hataymış', 'TR', '2018-12-18 23:28:14', '2018-12-18 23:28:14');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
